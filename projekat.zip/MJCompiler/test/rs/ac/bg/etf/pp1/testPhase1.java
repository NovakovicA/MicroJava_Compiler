package rs.ac.bg.etf.pp1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import java_cup.runtime.Symbol;

public class testPhase1 {

	
	
	public static void main(String[] args) throws IOException {
		Yylex lexer = new Yylex(new BufferedReader(new FileReader(new File("test/rs/ac/bg/etf/pp1/testPhase1.txt"))));
		Symbol token=lexer.next_token();
		while(token.sym!=sym.EOF) {
			System.out.println(token.value + " " + token.sym);
			token=lexer.next_token();
		}
	}
}

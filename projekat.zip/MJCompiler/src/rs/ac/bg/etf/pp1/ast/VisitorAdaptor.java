// generated with ast extension for cup
// version 0.8
// 6/1/2021 16:21:18


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(Designator Designator) { }
    public void visit(Factor Factor) { }
    public void visit(AddopTermList AddopTermList) { }
    public void visit(Mulop Mulop) { }
    public void visit(VarDec VarDec) { }
    public void visit(DesignatorStatement DesignatorStatement) { }
    public void visit(Expr1 Expr1) { }
    public void visit(ClassDec ClassDec) { }
    public void visit(CondFact CondFact) { }
    public void visit(Expr Expr) { }
    public void visit(VarDecPonistiv VarDecPonistiv) { }
    public void visit(ConstDec ConstDec) { }
    public void visit(FormPars FormPars) { }
    public void visit(MethodDec MethodDec) { }
    public void visit(MethodsDec MethodsDec) { }
    public void visit(CaseList CaseList) { }
    public void visit(Addop Addop) { }
    public void visit(MethodDecList MethodDecList) { }
    public void visit(Statement Statement) { }
    public void visit(Relop Relop) { }
    public void visit(NumConstList NumConstList) { }
    public void visit(ConstList ConstList) { }
    public void visit(Term Term) { }
    public void visit(CondTerm CondTerm) { }
    public void visit(Condition Condition) { }
    public void visit(ActPars ActPars) { }
    public void visit(ProgramList ProgramList) { }
    public void visit(VarDecList VarDecList) { }
    public void visit(StatementList StatementList) { }
    public void visit(MulopMod MulopMod) { visit(); }
    public void visit(MulopDivide MulopDivide) { visit(); }
    public void visit(MulopAsterisk MulopAsterisk) { visit(); }
    public void visit(AddopMinus AddopMinus) { visit(); }
    public void visit(AddopPlus AddopPlus) { visit(); }
    public void visit(RelopLessEq RelopLessEq) { visit(); }
    public void visit(RelopLess RelopLess) { visit(); }
    public void visit(RelopGreaterEq RelopGreaterEq) { visit(); }
    public void visit(RelopGreater RelopGreater) { visit(); }
    public void visit(RelopNotEqual RelopNotEqual) { visit(); }
    public void visit(RelopEqual RelopEqual) { visit(); }
    public void visit(Assignop Assignop) { visit(); }
    public void visit(Designator3 Designator3) { visit(); }
    public void visit(Designator2 Designator2) { visit(); }
    public void visit(Designator1 Designator1) { visit(); }
    public void visit(Factor9 Factor9) { visit(); }
    public void visit(Factor8 Factor8) { visit(); }
    public void visit(Factor7 Factor7) { visit(); }
    public void visit(Factor6 Factor6) { visit(); }
    public void visit(Factor5 Factor5) { visit(); }
    public void visit(Factor4 Factor4) { visit(); }
    public void visit(Factor3 Factor3) { visit(); }
    public void visit(Factor2 Factor2) { visit(); }
    public void visit(Factor1 Factor1) { visit(); }
    public void visit(Term1 Term1) { visit(); }
    public void visit(SingleTerm SingleTerm) { visit(); }
    public void visit(AddopTermListEmpty AddopTermListEmpty) { visit(); }
    public void visit(AddopTermList1 AddopTermList1) { visit(); }
    public void visit(Expression1 Expression1) { visit(); }
    public void visit(Expression1Minus Expression1Minus) { visit(); }
    public void visit(ExpressionEnd ExpressionEnd) { visit(); }
    public void visit(Expression Expression) { visit(); }
    public void visit(CondFactMultiple CondFactMultiple) { visit(); }
    public void visit(CondFactSingle CondFactSingle) { visit(); }
    public void visit(CondTermSingle CondTermSingle) { visit(); }
    public void visit(CondTermMultiple CondTermMultiple) { visit(); }
    public void visit(ConditionSingle ConditionSingle) { visit(); }
    public void visit(ConditionMultiple ConditionMultiple) { visit(); }
    public void visit(ActPararameter ActPararameter) { visit(); }
    public void visit(ActParameters ActParameters) { visit(); }
    public void visit(DesignatorStatementDerived1 DesignatorStatementDerived1) { visit(); }
    public void visit(DesStatMM DesStatMM) { visit(); }
    public void visit(DesStatPP DesStatPP) { visit(); }
    public void visit(DesStatPars DesStatPars) { visit(); }
    public void visit(DesStatEmpty DesStatEmpty) { visit(); }
    public void visit(DesStatement DesStatement) { visit(); }
    public void visit(NoCaseList NoCaseList) { visit(); }
    public void visit(CaseList1 CaseList1) { visit(); }
    public void visit(EmpNumConstList EmpNumConstList) { visit(); }
    public void visit(NumConstList1 NumConstList1) { visit(); }
    public void visit(EmptyStatmentList EmptyStatmentList) { visit(); }
    public void visit(StatmentList StatmentList) { visit(); }
    public void visit(StatList StatList) { visit(); }
    public void visit(PrintStat PrintStat) { visit(); }
    public void visit(ReadStat ReadStat) { visit(); }
    public void visit(RetStat RetStat) { visit(); }
    public void visit(RetEmpStat RetEmpStat) { visit(); }
    public void visit(ConStat ConStat) { visit(); }
    public void visit(BreakStat BreakStat) { visit(); }
    public void visit(SwitchStat SwitchStat) { visit(); }
    public void visit(DoWhileStat DoWhileStat) { visit(); }
    public void visit(IfElseStat IfElseStat) { visit(); }
    public void visit(IfStat IfStat) { visit(); }
    public void visit(DesStat DesStat) { visit(); }
    public void visit(Type Type) { visit(); }
    public void visit(FormPar2 FormPar2) { visit(); }
    public void visit(FormPar1 FormPar1) { visit(); }
    public void visit(FormPars2 FormPars2) { visit(); }
    public void visit(FormPars1 FormPars1) { visit(); }
    public void visit(VarDeclPonistivEmpty VarDeclPonistivEmpty) { visit(); }
    public void visit(VarDeclPonistiv VarDeclPonistiv) { visit(); }
    public void visit(MethodDecName MethodDecName) { visit(); }
    public void visit(MethodDec4 MethodDec4) { visit(); }
    public void visit(MethodDec3 MethodDec3) { visit(); }
    public void visit(MethodDec2 MethodDec2) { visit(); }
    public void visit(MethodDec1 MethodDec1) { visit(); }
    public void visit(MethodsDecEmpty MethodsDecEmpty) { visit(); }
    public void visit(MethodsDec1 MethodsDec1) { visit(); }
    public void visit(MethodList MethodList) { visit(); }
    public void visit(Class Class) { visit(); }
    public void visit(ClassExt ClassExt) { visit(); }
    public void visit(VarDecListDerived2 VarDecListDerived2) { visit(); }
    public void visit(VarDecListDerived1 VarDecListDerived1) { visit(); }
    public void visit(VariableDecList VariableDecList) { visit(); }
    public void visit(VariableDecListArr VariableDecListArr) { visit(); }
    public void visit(SingleVariableDec SingleVariableDec) { visit(); }
    public void visit(SingleVariableDecArr SingleVariableDecArr) { visit(); }
    public void visit(VarDecl VarDecl) { visit(); }
    public void visit(NoConDec NoConDec) { visit(); }
    public void visit(BoolConDec BoolConDec) { visit(); }
    public void visit(CharConDec CharConDec) { visit(); }
    public void visit(NumConDec NumConDec) { visit(); }
    public void visit(BoolConDeclaration BoolConDeclaration) { visit(); }
    public void visit(CharConDeclaration CharConDeclaration) { visit(); }
    public void visit(NumConDeclaration NumConDeclaration) { visit(); }
    public void visit(ProgramName ProgramName) { visit(); }
    public void visit(ProgramListEmpty ProgramListEmpty) { visit(); }
    public void visit(ProgramListClass ProgramListClass) { visit(); }
    public void visit(ProgramListVar ProgramListVar) { visit(); }
    public void visit(ProgramListConst ProgramListConst) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}

package rs.ac.bg.etf.pp1;

import rs.etf.pp1.mj.runtime.Code;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.*;

import java.util.Stack;

import rs.ac.bg.etf.pp1.ast.*;

public class CodeGenerator extends VisitorAdaptor {
	private int mainpc;
	private Stack<Integer> patchStack=new Stack<Integer>();
	// 1+, 2-
	private Stack<Integer> addopStack=new Stack<Integer>();
	// 1*, 2/, 3%
	private Stack<Integer> mulopStack=new Stack<Integer>();
	
	public int mainpc() {return mainpc;}
	
public void visit(MethodDecName a){
		
		if("main".equalsIgnoreCase(a.getName())){
			mainpc = Code.pc;
		}
		a.obj.setAdr(Code.pc);
		SyntaxNode methodNode = a.getParent();
	
		CountVar cnt = new CountVar();
		methodNode.traverseTopDown(cnt);
		
		Code.put(Code.enter);
		Code.put(0);
		Code.put(cnt.count);
	}

public void visit(MethodDec4 a){
	Code.put(Code.exit);
	Code.put(Code.return_);
}

public void visit(Designator1 a) {
	if(a.getParent().getClass()!=DesStatement.class && a.getParent().getClass()!=ReadStat.class )
	{
	Code.load(a.obj);
	if(a.obj.getType().getKind()==Struct.Array && (a.getParent().getParent().getClass()==DesStatPP.class 
			|| a.getParent().getParent().getClass()==DesStatMM.class)) {
		Code.load(a.obj);
	}
	}
}

public void visit(Designator3 a) {
	if(a.getDesignator().obj.getType().getKind()==Struct.Array && (a.getParent().getClass()==DesStatPP.class 
			|| a.getParent().getClass()==DesStatMM.class)) {
		Code.put(Code.dup_x1);
	}
	if(a.getParent().getClass()!=DesStatement.class  && a.getParent().getClass()!=ReadStat.class ) {
	if(a.getDesignator().obj.getType().getKind()==Struct.Array && a.getDesignator().obj.getType().getElemType().getKind()==Struct.Char) {
		Code.put(Code.baload);
	}
	else {
		Code.put(Code.aload);
	}
	}
}


public void visit(Factor4 a) {
	Obj con=new Obj(Obj.Con,"",a.struct);
	con.setAdr(a.getN1());
	con.setLevel(0);
	Code.load(con);
}

public void visit(Factor5 a) {
	Obj con=new Obj(Obj.Con,"",a.struct);
	con.setAdr(a.getC1().charAt(1));
	con.setLevel(0);
	Code.load(con);
}

public void visit(Factor6 a) {
	Obj con=new Obj(Obj.Con,"",a.struct);
	con.setAdr((Boolean.parseBoolean(a.getB1())) ? 1 : 0);
	con.setLevel(0);
	Code.load(con);
}


public void visit(Factor8 a) {
	Code.put(Code.newarray);
	if(a.getType().getTypeName().equalsIgnoreCase("char") || a.getType().getTypeName().equalsIgnoreCase("bool")) {
		Code.put(0);
	}
	else {
		Code.put(1);
	}
}


public void visit(DesStatPP a) {
	Code.loadConst(1);
	Code.put(Code.add);
	Code.store(a.getDesignator().obj);
}

public void visit(DesStatMM a) {
	Code.loadConst(1);
	Code.put(Code.sub);
	Code.store(a.getDesignator().obj);
}

public void visit(DesStatement a) {
	Code.store(a.getDesignator().obj);
}

public void visit(MulopAsterisk a) {mulopStack.push(1);}
public void visit(MulopDivide a) {mulopStack.push(2);}
public void visit(MulopMod a) {mulopStack.push(3);}

public void visit(AddopPlus a) {addopStack.push(1);}
public void visit(AddopMinus a) {addopStack.push(2);}


public void visit(Term1 a) {
switch(mulopStack.pop()) {
case 1: Code.put(Code.mul); break;
case 2: Code.put(Code.div); break;
case 3: Code.put(Code.rem); break;
}
}

public void visit(SingleTerm a) {
	if(a.getParent().getClass()==Expression1Minus.class) Code.put(Code.neg);
}

public void visit(AddopTermList1 a) {
	switch(addopStack.pop()) {
	case 1: Code.put(Code.add); break;
	case 2: Code.put(Code.sub); break;
	}
}

public void visit(ReadStat a) {
	if(a.getDesignator().obj.getType() == Tab.charType){
		Code.put(Code.bread);
		Code.store(a.getDesignator().obj);
	}else{
		Code.put(Code.read);
		Code.store(a.getDesignator().obj);
	}	
}

public void visit(PrintStat a) {
	if(a.getExpr().struct.getKind()==Struct.Char){
		Code.put(Code.bprint);
	}else{
		Code.put(Code.print);
	}	
}

public void visit(NumConstList1 a) {
	Code.loadConst(a.getNum());
}

public void visit(EmpNumConstList a) {
	Code.loadConst(1);
}


public void visit(Expression1Minus a) {
}

public void visit(Expression1 a) {
	if(a.getParent().getClass()==Expression.class) {
		if( ((Expression)a.getParent()).getExpr1()==a) {
		Code.loadConst(0);
		patchStack.push(Code.pc+1);
		Code.putFalseJump(Code.ne, 0);
		}
		else if(((Expression)a.getParent()).getExpr11()==a){
			Code.putJump(0);	
			Code.fixup(patchStack.pop());
			patchStack.push(Code.pc-2);
		}
		else if(((Expression)a.getParent()).getExpr12()==a){
			Code.fixup(patchStack.pop());
		}
	}
}



	



class CountVar extends VisitorAdaptor{
	public int count=0;
	public void visit(VariableDecList a) {count++;}
	public void visit(VariableDecListArr a) {count++;}
	public void visit(SingleVariableDec a) {count++;}
	public void visit(SingleVariableDecArr a) {count++;}
}

}

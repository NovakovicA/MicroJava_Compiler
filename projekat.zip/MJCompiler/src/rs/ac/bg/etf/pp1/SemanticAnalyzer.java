package rs.ac.bg.etf.pp1;

import org.apache.log4j.Logger;

import rs.ac.bg.etf.pp1.ast.*;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.Obj;
import rs.etf.pp1.symboltable.concepts.Struct;

public class SemanticAnalyzer extends VisitorAdaptor {
	Logger log = Logger.getLogger(getClass());
	private boolean errorDetected = false;
	
	private Type currentType=null;
	private boolean mainDeclared=false;
	private Obj currentMethod=null;
	
	public int numberOfGlobalVar=0;

	
	
	
	public void report_error(String message, SyntaxNode info) {
		errorDetected = true;
		StringBuilder msg = new StringBuilder(message);
		int line = (info == null) ? 0: info.getLine();
		if (line != 0)
			msg.append (" na liniji ").append(line);
		log.error(msg.toString());
	}

	public void report_info(String message, SyntaxNode info) {
		StringBuilder msg = new StringBuilder(message); 
		int line = (info == null) ? 0: info.getLine();
		if (line != 0)
			msg.append (" na liniji ").append(line);
		log.info(msg.toString());
	}
	
	public void visit(ProgramName programName){
    	programName.obj = Tab.insert(Obj.Prog, programName.getProgName(), Tab.noType);
    	Tab.openScope();
    }
    
    public void visit(Program program){
    	numberOfGlobalVar=Tab.currentScope().getnVars();
    	Tab.chainLocalSymbols(program.getProgramName().obj);
    	Tab.closeScope();
    }
    
    public void visit(Type type) {
    	Obj t = Tab.find(type.getTypeName());
    	currentType=type;
    	if(t == Tab.noObj){
    		report_error("Greska: Nije pronadjen tip " + type.getTypeName() + " u tabeli simbola! ", null);
    		type.struct = Tab.noType;
    	}
    	else if(Obj.Type == t.getKind())
    		{
    		type.struct = t.getType();
    		}
    	else
    		{
    		report_error("Greska: Ime " + type.getTypeName() + " ne predstavlja tip!", type);
    		type.struct = Tab.noType;
    		}
    	}
    
    
    public void visit(NumConDeclaration a) {
    	if(!currentType.getTypeName().equals("int")) {
    		report_error("Greska: Konstanta " + a.getConstName() + " je pogresnog tipa " + currentType.getTypeName(),a);
    	}
    	else if(Tab.find(a.getConstName())==Tab.noObj) {
    	Obj aa=Tab.insert(Obj.Con, a.getConstName(), a.getType().struct );
    	aa.setAdr(a.getVal());
    	}
    	else {
    		report_error("Greska: Simbol " + a.getConstName() + " je vec deklarisan",a);
    	}
    }
    public void visit(CharConDeclaration a) {
    	if(!currentType.getTypeName().equals("char")) {
    		report_error("Greska: Konstanta " + a.getConstName() + " je pogresnog tipa " + currentType.getTypeName(),a);
    	}
    	else if(Tab.find(a.getConstName())==Tab.noObj) {
    	Obj aa=Tab.insert(Obj.Con, a.getConstName(), a.getType().struct );
    	aa.setAdr(a.getVal().charAt(1));
    	}
    	else {
    		report_error("Greska: Simbol " + a.getConstName() + " je vec deklarisan",a);
    	}
    }
    public void visit(BoolConDeclaration a) {
        if(!currentType.getTypeName().equals("bool")) {
        	report_error("Greska: Konstanta " + a.getConstName() + " je pogresnog tipa " + currentType.getTypeName(),a);
        }
        else if(Tab.find(a.getConstName())==Tab.noObj) {
    	Obj aa=Tab.insert(Obj.Con, a.getConstName(), a.getType().struct );
    	aa.setAdr((Boolean.parseBoolean(a.getVal())) ? 1 : 0);
    	}
    	else {
    		report_error("Greska: Simbol " + a.getConstName() + " je vec deklarisan",a);
    	}
    }
    
    public void visit(NumConDec a) {
    	if(!currentType.getTypeName().equals("int")) {
    		report_error("Greska: Konstanta " + a.getConstName() + " je pogresnog tipa",a);
    	}
    	else if(Tab.find(a.getConstName())==Tab.noObj) {
    	Obj aa=Tab.insert(Obj.Con, a.getConstName(), currentType.struct );	
    	aa.setAdr(a.getVal());
    	}
    	else {
    		report_error("Greska: Simbol " + a.getConstName() + " je vec deklarisan",a);
    	}
    }
    public void visit(CharConDec a) {
    	if(!currentType.getTypeName().equals("char")) {
    		report_error("Greska: Konstanta " + a.getConstName() + " je pogresnog tipa",a);
    	}
    	if(Tab.find(a.getConstName())==Tab.noObj) {
    	Obj aa=Tab.insert(Obj.Con, a.getConstName(), currentType.struct );
    	aa.setAdr(a.getVal().charAt(1));
    	}
    	else {
    		report_error("Greska: Simbol " + a.getConstName() + " je vec deklarisan",a);
    	}
    }
    public void visit(BoolConDec a) {
    	if(!currentType.getTypeName().equals("bool")) {
    		report_error("Greska: Konstanta " + a.getConstName() + " je pogresnog tipa",a);
    	}
    	if(Tab.find(a.getConstName())==Tab.noObj) {
    	Obj aa=Tab.insert(Obj.Con, a.getConstName(), currentType.struct );
    	aa.setAdr((Boolean.parseBoolean(a.getVal())) ? 1 : 0);
    	}
    	else {
    		report_error("Greska: Simbol " + a.getConstName() + " je vec deklarisan",a);
    	}
    }
    
    
    public void visit(VariableDecList a) {
    	if(Tab.find(a.getVarName())==Tab.noObj) {
    		Tab.insert(Obj.Var, a.getVarName(), currentType.struct );
    	}
    	else {
    		report_error("Greska: Simbol " + a.getVarName() + " je vec deklarisan",a);
    	}
    }
    public void visit(VariableDecListArr a) {
    	if(!currentType.getTypeName().equals("char") && !currentType.getTypeName().equals("int")
    			&& !currentType.getTypeName().equals("bool")) {
    		report_error("Greska: Niz nije podrzanog tipa (int/char/bool) ",a);
    	}
    	else if(Tab.find(a.getVarName())==Tab.noObj) {
    	Tab.insert(Obj.Var, a.getVarName(), Tab.find("Arr" + currentType.getTypeName()).getType());
    	}
    	else {
    		report_error("Greska: Simbol " + a.getVarName() + " je vec deklarisan",a);
    	}
    }
    public void visit(SingleVariableDec a) {
    	if(Tab.find(a.getVarName())==Tab.noObj) {
    	Tab.insert(Obj.Var, a.getVarName(), currentType.struct );
    	}
    	else {
    		report_error("Greska: Simbol " + a.getVarName() + " je vec deklarisan",a);
    	}
    }
    public void visit(SingleVariableDecArr a) {
    	if(!currentType.getTypeName().equals("char") && !currentType.getTypeName().equals("int")
    			&& !currentType.getTypeName().equals("bool")) {
    		report_error("Greska: Niz nije podrzanog tipa (int/char/bool) ",a);
    	}
    	else if(Tab.find(a.getVarName())==Tab.noObj) {
    	Tab.insert(Obj.Var, a.getVarName(), Tab.find("Arr" + currentType.getTypeName()).getType());
    	}
    	else {
    		report_error("Greska: Simbol " + a.getVarName() + " je vec deklarisan",a);
    	}
    }
    
    
    public void visit(MethodDecName a) {
    	if (!a.getName().equalsIgnoreCase("main")) {
    		report_error("Greska: Ime metode nije podrzano!",a);
    	}
    	else if (mainDeclared) report_error("Greska: Moguce je imati samo jednu main metodu",a);
    	else {
    	currentMethod = Tab.insert(Obj.Meth, a.getName(), new Struct(Struct.None));
    	a.obj = currentMethod;
    	Tab.openScope();
    	mainDeclared=true;
    	}
    }
   
    
    
    public void visit(MethodDec4 a) {
    	Tab.chainLocalSymbols(currentMethod);
    	Tab.closeScope();
    }
    
    
    public void visit(DesStatement a) {
    	
    	if(a.getDesignator().obj.getKind()==Obj.Con || a.getDesignator().obj.getKind()==Obj.Type
    			|| a.getDesignator().obj.getKind()==Obj.Meth || a.getDesignator().obj.getKind()==Obj.Prog)
    	{
    		report_error("Greska: Odrediste je nije pravilno (promenljiva, element niza, polje klase)",a);
    	}
    	else if (!a.getDesignator().obj.getType().compatibleWith(a.getExpr().struct)) {
    		report_error("Greska: Tipovi nisu kompatibilni" ,a);
    	}
    	else {
    		//report_info("" + a.getDesignator().obj.getType().getKind(),null);
    		//report_info("" + a.getDesignator().obj.getType().getElemType().getKind(),null);
    		//report_info("" + a.getExpr().struct.getKind(),null);
    		//report_info("" + a.getExpr().struct.getElemType().getKind(),null);
    	}
    }
    
    public void visit(DesStatPP a) {
    	if(!(a.getDesignator().obj.getKind()==Obj.Var || a.getDesignator().obj.getKind()==Obj.Elem || a.getDesignator().obj.getKind()==Obj.Fld))
    	{
    		report_error("Greska: Operator nije pravilan (promenljiva, element niza, polje klase)",a);
    	}
    	else if(!a.getDesignator().obj.getType().equals(Tab.find("int").getType())){
    		report_error("Greska: Operator nije int",a);
    	}
    }
    public void visit(DesStatMM a) {
    	if(!(a.getDesignator().obj.getKind()==Obj.Var || a.getDesignator().obj.getKind()==Obj.Elem || a.getDesignator().obj.getKind()==Obj.Fld))
    	{
    		report_error("Greska: Operator nije pravilan (promenljiva, element niza, polje klase)",a);
    	}
    	else if(!a.getDesignator().obj.getType().equals(Tab.find("int").getType())){
    		report_error("Greska: Operator nije int",a);
    	}
    }
    
    
    public void visit(ReadStat a) {
    	if(!(a.getDesignator().obj.getKind()==Obj.Var || a.getDesignator().obj.getKind()==Obj.Elem || a.getDesignator().obj.getKind()==Obj.Fld))
    	{
    		report_error("Greska: Operator nije pravilan (promenljiva, element niza, polje klase)",a);
    	}
    	else if(!(a.getDesignator().obj.getType().equals(Tab.find("int").getType()) 
    			|| a.getDesignator().obj.getType().equals(Tab.find("char").getType()) 
    			|| a.getDesignator().obj.getType().equals(Tab.find("bool").getType()))) {
    		report_error("Greska: Operator nije int/char/bool",a);
    	}
    }
    
    public void visit(PrintStat a) {
    	if(!(a.getExpr().struct.equals(Tab.find("int").getType()) 
    			|| a.getExpr().struct.equals(Tab.find("char").getType()) 
    			|| a.getExpr().struct.equals(Tab.find("bool").getType()))) {
    		report_error("Greska: Operator nije int/char/bool",a);
    	}
    }
    
    public void visit(Expression1Minus a) {
    	a.struct=a.getTerm().struct;
    	if(!a.getTerm().struct.equals(Tab.find("int").getType())) {
    		report_error("Greska: Operator nije int",a);
    	}
    }
    
    public void visit(AddopTermList1 a) {
    	if(!a.getTerm().struct.equals(Tab.find("int").getType())) {
    		report_error("Greska: Operator nije int",a);
    	}
    }
    
    public void visit(Expression a) {
    	a.struct=a.getExpr11().struct;
    	if(!a.getExpr11().struct.equals(a.getExpr12().struct)) {
    		report_error("Greska: Obe vrednosti moraju biti istog tipa",a);
    	}	
    }
    
    public void visit(Term1 a) {
    	a.struct=a.getTerm().struct;
    	if(!a.getTerm().struct.equals(Tab.find("int").getType()) 
    			&& !a.getFactor().struct.equals(Tab.find("int").getType())) {
    		report_error("Greska: Operatori nisu tipa int",a);
    	}
    }
    
    public void visit(Factor8 a) {
    	a.struct = Tab.find("Arr" + a.getType().getTypeName()).getType();
    	if(!a.getExpr().struct.equals(Tab.find("int").getType())) {
    		report_error("Greska: Broj elemenata niza mora biti deklarisan kao int",a);
    	}
    }
    
    public void visit(Designator3 a) {
    	a.obj=a.getDesignator().obj;
    	if(!a.obj.getType().equals(Tab.find("Arrint").getType()) && !a.obj.getType().equals(Tab.find("Arrchar").getType())
    			 && !a.obj.getType().equals(Tab.find("Arrbool").getType())) {
    		report_error("Greska: Operand nije niz",a);
    	}
    else if(!a.getExpr().struct.equals(Tab.find("int").getType())) {
    		report_error("Greska: Indeks niza mora biti deklarisan kao int",a);
    	}
    else {
    	a.obj = new Obj(Obj.Elem,a.getDesignator().obj.getName(),a.getDesignator().obj.getType().getElemType());
    }
    }
    
    public void visit(Designator1 a){
    	Obj obj = Tab.find(a.getName());
    	if(obj == Tab.noObj){
			report_error("Greska na liniji " + a.getLine()+ " : ime "+a.getName()+" nije deklarisano! ", null);
    	}
    	else if (obj.getKind()==Obj.Var || obj.getKind()==Obj.Con){
    		report_info("Detektovano koriscenje simbola " + obj.getName() , a);
    		displaySymbol(obj);
    	}
    	a.obj = obj;
    }
    
    
    public void visit(SingleTerm a){
    	a.struct = a.getFactor().struct;
    }
    
    public void visit(Factor1 a){
    	a.struct = a.getDesignator().obj.getType();
    }
    
    public void visit(Factor4 a){
    	a.struct = Tab.find("int").getType();
    }
    
    public void visit(Factor5 a){
    	a.struct = Tab.find("char").getType();
    }
    
    public void visit(Factor6 a){
    	a.struct = Tab.find("bool").getType();
    }
    

    public void visit(Factor9 a){
    	a.struct = a.getExpr().struct;
    }

    
    public void visit(ExpressionEnd a) {
    	a.struct=a.getExpr1().struct;
    }
    
    public void visit(Expression1 a) {
    	a.struct=a.getTerm().struct;
    }
    
    
    public void visit(DesStatPars a) {report_error("Pozivanje metoda nije podrzano.",a);}
    public void visit(Factor7 a){report_error("New parametar nije podrzan.",a);}
    public void visit(Factor2 a){report_error("Pozivanje metoda nije podrzano.",a);}
    public void visit(Factor3 a){report_error("Pozivanje metoda nije podrzano.",a);}
     public void visit(MethodDec1 a) {report_error("Ovakav tip metode nije podrzan.",a);}
     public void visit(MethodDec2 a) {report_error("Ovakav tip metode nije podrzan.",a);}
     public void visit(MethodDec3 a) {report_error("Ovakav tip metode nije podrzan.",a);}
     public void visit(IfStat a) {report_error("Ovakav tip instrukcije.",a);}
     public void visit(IfElseStat a) {report_error("Ovakav tip instrukcije.",a);}
     public void visit(DoWhileStat a) {report_error("Ovakav tip instrukcije.",a);}
     public void visit(SwitchStat a) {report_error("Ovakav tip instrukcije.",a);}
     public void visit(BreakStat a) {report_error("Ovakav tip instrukcije.",a);}
     public void visit(ConStat a) {report_error("Ovakav tip instrukcije.",a);}
     public void visit(RetStat a) {report_error("Ovakav tip instrukcije.",a);} 
     public void visit(RetEmpStat a) {report_error("Ovakav tip instrukcije.",a);}
     public void visit(ActPars a) {report_error("Aktivni parametri nisu podrzani.",a);}
     public void visit(FormPars a) {report_error("Formalni parametri nisu podrzani.",a);}
    public void init() {
    	Tab.init();
    	Tab.insert(Obj.Type,"bool",new Struct(Struct.Bool));
    	Tab.insert(Obj.Type, "Arrint", new Struct(Struct.Array,Tab.find("int").getType()));
    	Tab.insert(Obj.Type, "Arrchar", new Struct(Struct.Array,Tab.find("char").getType()));
    	Tab.insert(Obj.Type, "Arrbool", new Struct(Struct.Array,Tab.find("bool").getType()));
    }
   
   
    public boolean passed() {
    	return !errorDetected;
    }
    
    
    
    private void displaySymbol(Obj objToVisit){
    	StringBuilder output = new StringBuilder();
		switch (objToVisit.getKind()) {
		case Obj.Con:  output.append("Con "); break;
		case Obj.Var:  output.append("Var "); break;
		case Obj.Type: output.append("Type "); break;
		case Obj.Meth: output.append("Meth "); break;
		case Obj.Fld:  output.append("Fld "); break;
		case Obj.Prog: output.append("Prog "); break;
		}
		
		output.append(objToVisit.getName());
		output.append(": ");
	
	switch(objToVisit.getType().getKind()) {
	case Struct.None:  output.append("None"); break;
	case Struct.Int: output.append("Int"); break;
	case Struct.Char: output.append("Char"); break;
	case Struct.Array: { output.append("Array ");
		switch(objToVisit.getType().getElemType().getKind()) {
		case Struct.None:  output.append("of None"); break;
		case Struct.Int: output.append("of Int"); break;
		case Struct.Char: output.append("of Char"); break;
		case Struct.Array:  output.append("of Array");break;
		case Struct.Class: output.append("of Class"); break;
		case Struct.Bool: output.append("of Bool"); break;
		case Struct.Enum: output.append("of Enum"); break;
		case Struct.Interface: output.append("ofInterface"); break;
		}
		break;}
	case Struct.Class: output.append("Class"); break;
	case Struct.Bool: output.append("Bool"); break;
	case Struct.Enum: output.append("Enum"); break;
	case Struct.Interface: output.append("Interface"); break;
		}
		output.append(", ");
		output.append(objToVisit.getAdr());
		output.append(", ");
		output.append(objToVisit.getLevel() + " ");
		report_info("Simbol " + output.toString(), null);
	}
}

// generated with ast extension for cup
// version 0.8
// 6/1/2021 16:21:18


package rs.ac.bg.etf.pp1.ast;

public class ProgramListClass extends ProgramList {

    private ClassDec ClassDec;
    private ProgramList ProgramList;

    public ProgramListClass (ClassDec ClassDec, ProgramList ProgramList) {
        this.ClassDec=ClassDec;
        if(ClassDec!=null) ClassDec.setParent(this);
        this.ProgramList=ProgramList;
        if(ProgramList!=null) ProgramList.setParent(this);
    }

    public ClassDec getClassDec() {
        return ClassDec;
    }

    public void setClassDec(ClassDec ClassDec) {
        this.ClassDec=ClassDec;
    }

    public ProgramList getProgramList() {
        return ProgramList;
    }

    public void setProgramList(ProgramList ProgramList) {
        this.ProgramList=ProgramList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ClassDec!=null) ClassDec.accept(visitor);
        if(ProgramList!=null) ProgramList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ClassDec!=null) ClassDec.traverseTopDown(visitor);
        if(ProgramList!=null) ProgramList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ClassDec!=null) ClassDec.traverseBottomUp(visitor);
        if(ProgramList!=null) ProgramList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ProgramListClass(\n");

        if(ClassDec!=null)
            buffer.append(ClassDec.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ProgramList!=null)
            buffer.append(ProgramList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ProgramListClass]");
        return buffer.toString();
    }
}

// generated with ast extension for cup
// version 0.8
// 6/1/2021 16:21:18


package rs.ac.bg.etf.pp1.ast;

public class Class extends ClassDec {

    private String className;
    private VarDecPonistiv VarDecPonistiv;
    private MethodDecList MethodDecList;

    public Class (String className, VarDecPonistiv VarDecPonistiv, MethodDecList MethodDecList) {
        this.className=className;
        this.VarDecPonistiv=VarDecPonistiv;
        if(VarDecPonistiv!=null) VarDecPonistiv.setParent(this);
        this.MethodDecList=MethodDecList;
        if(MethodDecList!=null) MethodDecList.setParent(this);
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className=className;
    }

    public VarDecPonistiv getVarDecPonistiv() {
        return VarDecPonistiv;
    }

    public void setVarDecPonistiv(VarDecPonistiv VarDecPonistiv) {
        this.VarDecPonistiv=VarDecPonistiv;
    }

    public MethodDecList getMethodDecList() {
        return MethodDecList;
    }

    public void setMethodDecList(MethodDecList MethodDecList) {
        this.MethodDecList=MethodDecList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(VarDecPonistiv!=null) VarDecPonistiv.accept(visitor);
        if(MethodDecList!=null) MethodDecList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(VarDecPonistiv!=null) VarDecPonistiv.traverseTopDown(visitor);
        if(MethodDecList!=null) MethodDecList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(VarDecPonistiv!=null) VarDecPonistiv.traverseBottomUp(visitor);
        if(MethodDecList!=null) MethodDecList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("Class(\n");

        buffer.append(" "+tab+className);
        buffer.append("\n");

        if(VarDecPonistiv!=null)
            buffer.append(VarDecPonistiv.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(MethodDecList!=null)
            buffer.append(MethodDecList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [Class]");
        return buffer.toString();
    }
}

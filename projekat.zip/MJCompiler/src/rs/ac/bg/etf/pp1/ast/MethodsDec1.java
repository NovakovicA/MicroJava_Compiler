// generated with ast extension for cup
// version 0.8
// 6/1/2021 16:21:18


package rs.ac.bg.etf.pp1.ast;

public class MethodsDec1 extends MethodsDec {

    private MethodsDec MethodsDec;
    private MethodDec MethodDec;

    public MethodsDec1 (MethodsDec MethodsDec, MethodDec MethodDec) {
        this.MethodsDec=MethodsDec;
        if(MethodsDec!=null) MethodsDec.setParent(this);
        this.MethodDec=MethodDec;
        if(MethodDec!=null) MethodDec.setParent(this);
    }

    public MethodsDec getMethodsDec() {
        return MethodsDec;
    }

    public void setMethodsDec(MethodsDec MethodsDec) {
        this.MethodsDec=MethodsDec;
    }

    public MethodDec getMethodDec() {
        return MethodDec;
    }

    public void setMethodDec(MethodDec MethodDec) {
        this.MethodDec=MethodDec;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(MethodsDec!=null) MethodsDec.accept(visitor);
        if(MethodDec!=null) MethodDec.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(MethodsDec!=null) MethodsDec.traverseTopDown(visitor);
        if(MethodDec!=null) MethodDec.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(MethodsDec!=null) MethodsDec.traverseBottomUp(visitor);
        if(MethodDec!=null) MethodDec.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("MethodsDec1(\n");

        if(MethodsDec!=null)
            buffer.append(MethodsDec.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(MethodDec!=null)
            buffer.append(MethodDec.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [MethodsDec1]");
        return buffer.toString();
    }
}

package rs.ac.bg.etf.pp1;

public class sym_old {

	
	public static int PROGRAM=1;
	public static int BREAK=2;
	public static int CLASS=3;
	public static int ENUM=4;
	public static int ELSE=5;
	public static int CONST=6;
	public static int IF=7;
	public static int SWITCH=8;
	public static int DO=9;
	public static int WHILE=10;
	public static int NEW=11;
	public static int PRINT=12;
	public static int READ=13;
	public static int RETURN=14;
	public static int VOID=15;
	public static int EXTENDS=16;
	public static int CONTINUE=17;
	public static int CASE=18;
	
	
	public static int IDENT=19;
	public static int NUMCONST=20;
	public static int CHARCONST=21;
	public static int BOOLCONST=22;
	
	public static int PLUS=23;
	public static int MINUS=24;
	public static int ASTERISK=25;
	public static int FSLASH=26;
	public static int PERCENT=27;
	public static int EQUAL2=28;
	public static int NOTEQUAL=29;
	public static int GREATER=30;
	public static int GREATEREQ=31;
	public static int LESS=32;
	public static int LESSEQ=33;
	public static int AND=34;
	public static int OR=35;
	public static int EQUAL=36;
	public static int PLUSPLUS=37;
	public static int MINUSMINUS=38;
	public static int SEMICOLON=39;
	public static int COMMA=40;
	public static int PERIOD=41;
	public static int LPAREN=42;
	public static int RPAREN=43;
	public static int LBRACKET=44;
	public static int RBRACKET=45;
	public static int LBRACE=46;
	public static int RBRACE=47;
	public static int QUEST=48;
	public static int COLON=49;
	
	public static int EOF=50;
}

// generated with ast extension for cup
// version 0.8
// 6/1/2021 16:21:18


package rs.ac.bg.etf.pp1.ast;

public class ProgramListConst extends ProgramList {

    private ConstDec ConstDec;
    private ProgramList ProgramList;

    public ProgramListConst (ConstDec ConstDec, ProgramList ProgramList) {
        this.ConstDec=ConstDec;
        if(ConstDec!=null) ConstDec.setParent(this);
        this.ProgramList=ProgramList;
        if(ProgramList!=null) ProgramList.setParent(this);
    }

    public ConstDec getConstDec() {
        return ConstDec;
    }

    public void setConstDec(ConstDec ConstDec) {
        this.ConstDec=ConstDec;
    }

    public ProgramList getProgramList() {
        return ProgramList;
    }

    public void setProgramList(ProgramList ProgramList) {
        this.ProgramList=ProgramList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ConstDec!=null) ConstDec.accept(visitor);
        if(ProgramList!=null) ProgramList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ConstDec!=null) ConstDec.traverseTopDown(visitor);
        if(ProgramList!=null) ProgramList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ConstDec!=null) ConstDec.traverseBottomUp(visitor);
        if(ProgramList!=null) ProgramList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ProgramListConst(\n");

        if(ConstDec!=null)
            buffer.append(ConstDec.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ProgramList!=null)
            buffer.append(ProgramList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ProgramListConst]");
        return buffer.toString();
    }
}
